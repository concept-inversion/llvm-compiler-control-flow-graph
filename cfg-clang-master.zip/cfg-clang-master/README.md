# Source Level Control flow Graph

* cd cfg-clang
* make

* ./tool tests/\<filename\>.c 
